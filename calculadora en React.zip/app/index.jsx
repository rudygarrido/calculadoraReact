import React from 'react'
import {render} from 'react-dom'
class App extends React.Component {
	
	constructor(props){
		super(props)
		this.state = {
			op : 0 ,
			display : "",
			number1 : "",
			number2 : "",
			operation : ""
		}
	}
	
	handleDisplayChange(numero){
		if(this.state.op == 1){
			this.setState({
				display : this.state.number2 +numero,
				number2: this.state.number2+numero
			})
		}else{
			this.setState({
				display : this.state.display + numero,
				number1: this.state.number1+numero
			})
		}
	}
	
	handleDisplayChangeOperation(action){
		if(action == "AC"){
			this.setState({
				display: " ",
				op : 0,
				number1 : "",
				number2 : "",
				operation : ""
			})
		}else if(action == "<--"){
			if(this.state.op == 1){
				this.setState({
					display : this.state.display.substr(0, this.state.display.length-1),
					number2: this.state.number2.substr(0, this.state.number2.length-1)
				})
			}else{
				this.setState({
					display : this.state.display.substr(0, this.state.display.length-1),
					number1: this.state.number1.substr(0, this.state.number1.length-1)
				})
			}
			
		}else if(action == "=") {
			const num1 = parseFloat(this.state.number1, 10)
			const num2 = parseFloat(this.state.number2, 10)
			let tot
			switch(this.state.operation){
				case "+":
					
					tot = num1 + num2
					this.setState({
						display: tot,
						number1 : tot,
						number2 : ""
					})
					break
				case "-":
					tot = num1 - num2
					this.setState({
						display: tot,
						number1 : tot,
						number2 : ""
					})
					break
				case "x":
					tot = num1 * num2
					this.setState({
						display: tot,
						number1 : tot,
						number2 : ""
					})
					break
				case "/":
					tot = num1 / num2
					this.setState({
						display: tot,
						number1 : tot,
						number2 : ""
					})
					break
			}
		}else{
			this.setState({
				display: this.state.display + action,
				op : 1,
				operation: action
			})
		}
	}
	
	render() {
		let buttons = []
		for(let i=0;i<10;i++){
			buttons.push(<Button number={i}/>)
		}
		return (		
			<div>
				<Display value={this.state.display} />
				<br/>
				<Button number="7" onClick={this.handleDisplayChange.bind(this,7)}/>
				<Button number="8" onClick={this.handleDisplayChange.bind(this,8)}/>
				<Button number="9" onClick={this.handleDisplayChange.bind(this,9)}/>
				<ButtonAction action="-" onClick={this.handleDisplayChangeOperation.bind(this,"-")}/>
				<br/>
				<Button number="4" onClick={this.handleDisplayChange.bind(this,4)}/>
				<Button number="5" onClick={this.handleDisplayChange.bind(this,5)}/>
				<Button number="6" onClick={this.handleDisplayChange.bind(this,6)}/>
				<ButtonAction action="+" onClick={this.handleDisplayChangeOperation.bind(this,"+")} />
				<br/>
				<Button number="1" onClick={this.handleDisplayChange.bind(this,1)}/>
				<Button number="2" onClick={this.handleDisplayChange.bind(this,2)}/>
				<Button number="3" onClick={this.handleDisplayChange.bind(this,3)}/>
				<ButtonAction action="x" onClick={this.handleDisplayChangeOperation.bind(this,"x")} />
				<ButtonAction action="/" onClick={this.handleDisplayChangeOperation.bind(this,"/")} />
				<br/>
				<ButtonAction action="AC" onClick={this.handleDisplayChangeOperation.bind(this,"AC")} />
				<ButtonAction action="<--" onClick={this.handleDisplayChangeOperation.bind(this,"<--")} />
				<Button number="0" onClick={this.handleDisplayChange.bind(this,0)}/>
				<ButtonAction action="=" onClick={this.handleDisplayChangeOperation.bind(this,"=")}/>
				<Button number="." onClick={this.handleDisplayChange.bind(this,".")}/>
			</div>
		)
	}
	

}

class Display extends React.Component{
	render(){
		return(
			<input value={this.props.value}/>
		)
	}
	
}

export class Button extends React.Component{
	render(){
		return(
			<button onClick={this.props.onClick} tabIndex={this.props.number} >
				{this.props.number}
			</button>
		)
		
		
	}
	
	
}

class ButtonAction extends React.Component{
	render(){
		return(
			<button onClick={this.props.onClick} >{this.props.action}</button>
		)
	}
	
}

render(<App/>, document.getElementById('app'))
